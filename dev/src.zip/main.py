
def main(event, context):
  print("test")
